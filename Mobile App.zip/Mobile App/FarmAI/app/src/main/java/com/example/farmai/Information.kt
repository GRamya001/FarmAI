package com.example.farmai

import android.app.AlertDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText

class Information : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_information)
        var crop = findViewById<View>(R.id.crop) as EditText
        var pc = findViewById<View>(R.id.enter) as Button
        pc.setOnClickListener {
            if((crop.text.toString()) == "cotton") {
                showMessage(
                    "Tips and price",
                    "phorate,endosulfan,aldicarb\nPrice of cotton per quintal is 5900"
                )
            }
            else if((crop.text.toString()) == "rice") {
                showMessage(
                    "Tips and price",
                    "dinotefuran\nPrice of rice is 5100"
                )
            }
            else if((crop.text.toString()) == "maize") {
                showMessage(
                    "Tips and price",
                    "dhanzyme gold\nPrice of maize is 2100"
                )
            }
            else {
                showMessage("Tips and price", "Not available")
            }
        }
    }


    fun showMessage(title: String?, message: String?) {
        val builder = AlertDialog.Builder(this)
        builder.setCancelable(true)
        builder.setTitle(title)
        builder.setMessage(message)
        builder.show()
    }
}