package com.example.farmai

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var pc = findViewById<View>(R.id.pc) as Button
        pc.setOnClickListener(View.OnClickListener { // TODO Auto-generated method stub
            val c = Intent(this@MainActivity, PredictionPage::class.java)
            startActivity(c)
        })
        var ci = findViewById<View>(R.id.ci) as Button
        ci.setOnClickListener(View.OnClickListener { // TODO Auto-generated method stub
            val p = Intent(this@MainActivity, Information::class.java)
            startActivity(p)
        })
    }
}