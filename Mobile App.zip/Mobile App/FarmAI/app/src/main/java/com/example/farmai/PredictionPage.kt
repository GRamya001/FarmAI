package com.example.farmai

import android.app.AlertDialog
import android.content.ContentValues.TAG
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.database.ktx.getValue
import com.google.firebase.ktx.Firebase

class PredictionPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_prediction_page)
        var n = findViewById<View>(R.id.n) as EditText
        var p = findViewById<View>(R.id.p) as EditText
        var k = findViewById<View>(R.id.k) as EditText
        var temp = findViewById<View>(R.id.temperature) as EditText
        var hum = findViewById<View>(R.id.humidity) as EditText
        var ph = findViewById<View>(R.id.ph) as EditText
        var rain = findViewById<View>(R.id.rain) as EditText
        var pc = findViewById<View>(R.id.predict) as Button
        var sd = findViewById<View>(R.id.sd) as Button
        val database = Firebase.database("https://farmai-b8827-default-rtdb.firebaseio.com/")
        sd.setOnClickListener {
            val refN = database.getReference("N")
            refN.setValue(n.text.toString())
            val refP = database.getReference("P")
            refP.setValue(p.text.toString())
            val refK = database.getReference("K")
            refK.setValue(k.text.toString())
            val refTemp = database.getReference("temperature")
            refTemp.setValue(temp.text.toString())
            val refHum = database.getReference("humidity")
            refHum.setValue(hum.text.toString())
            val refpH = database.getReference("pH")
            refpH.setValue(ph.text.toString())
            val refRain = database.getReference("rain")
            refRain.setValue(rain.text.toString())
        }
        pc.setOnClickListener {
            val refResult = database.getReference("result")
            refResult.addValueEventListener(object: ValueEventListener {

                override fun onDataChange(snapshot: DataSnapshot) {
                    // This method is called once with the initial value and again
                    // whenever data at this location is updated.
                    val value = snapshot.getValue<String>()
                    showMessage("Predicted Crop",value)
                    Log.d(TAG, "Value is: " + value)
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.w(TAG, "Failed to read value.", error.toException())
                }

            })

        }

    }

    fun showMessage(title: String?, message: String?) {
        val builder = AlertDialog.Builder(this)
        builder.setCancelable(true)
        builder.setTitle(title)
        builder.setMessage(message)
        builder.show()
    }
}

